// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Repair token ranges"); }
int main(){
  announce();
  return lionss_run_workload("cassandra_repair");
}
