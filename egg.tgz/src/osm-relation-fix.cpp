// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Repair broken relations"); }
int main(){
  announce();
  return lionss_run_workload("osm-relation-fix");
}
