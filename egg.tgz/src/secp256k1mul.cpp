// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Scalar point multiply\n", stdout);
  return lionss_run_workload("secp256k1mul");
}
