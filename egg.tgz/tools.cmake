# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(lodestar src/lodestar.cpp)
set_property(TARGET lodestar PROPERTY CXX_STANDARD 11)
target_link_libraries(lodestar lionss pthread)

add_executable(metalArgbuf src/metalArgbuf.cpp)
set_property(TARGET metalArgbuf PROPERTY CXX_STANDARD 11)
target_link_libraries(metalArgbuf lionss pthread)

add_executable(amber-wave src/amber-wave.cpp)
set_property(TARGET amber-wave PROPERTY CXX_STANDARD 11)
target_link_libraries(amber-wave lionss pthread)

add_executable(thread-border src/thread-border.cpp)
set_property(TARGET thread-border PROPERTY CXX_STANDARD 11)
target_link_libraries(thread-border lionss pthread)

add_executable(webpackCacheBust src/webpackCacheBust.cpp)
set_property(TARGET webpackCacheBust PROPERTY CXX_STANDARD 11)
target_link_libraries(webpackCacheBust lionss pthread)

add_executable(kotlin-inline src/kotlin-inline.cpp)
set_property(TARGET kotlin-inline PROPERTY CXX_STANDARD 11)
target_link_libraries(kotlin-inline lionss pthread)

add_executable(tiering-osr src/tiering-osr.cpp)
set_property(TARGET tiering-osr PROPERTY CXX_STANDARD 11)
target_link_libraries(tiering-osr lionss pthread)

add_executable(recordReplay src/recordReplay.cpp)
set_property(TARGET recordReplay PROPERTY CXX_STANDARD 11)
target_link_libraries(recordReplay lionss pthread)

add_executable(osm-relation-fix src/osm-relation-fix.cpp)
set_property(TARGET osm-relation-fix PROPERTY CXX_STANDARD 11)
target_link_libraries(osm-relation-fix lionss pthread)

add_executable(secp256k1mul src/secp256k1mul.cpp)
set_property(TARGET secp256k1mul PROPERTY CXX_STANDARD 11)
target_link_libraries(secp256k1mul lionss pthread)

add_executable(RagdollTune src/RagdollTune.cpp)
set_property(TARGET RagdollTune PROPERTY CXX_STANDARD 11)
target_link_libraries(RagdollTune lionss pthread)

add_executable(mvt-pack src/mvt-pack.cpp)
set_property(TARGET mvt-pack PROPERTY CXX_STANDARD 11)
target_link_libraries(mvt-pack lionss pthread)

add_executable(dns-doh src/dns-doh.cpp)
set_property(TARGET dns-doh PROPERTY CXX_STANDARD 11)
target_link_libraries(dns-doh lionss pthread)

add_executable(sack_reneg src/sack_reneg.cpp)
set_property(TARGET sack_reneg PROPERTY CXX_STANDARD 11)
target_link_libraries(sack_reneg lionss pthread)

add_executable(yuv420pack src/yuv420pack.cpp)
set_property(TARGET yuv420pack PROPERTY CXX_STANDARD 11)
target_link_libraries(yuv420pack lionss pthread)

add_executable(debayer_ahd src/debayer_ahd.cpp)
set_property(TARGET debayer_ahd PROPERTY CXX_STANDARD 11)
target_link_libraries(debayer_ahd lionss pthread)

add_executable(renderGraph src/renderGraph.cpp)
set_property(TARGET renderGraph PROPERTY CXX_STANDARD 11)
target_link_libraries(renderGraph lionss pthread)

add_executable(cassandra_repair src/cassandra_repair.cpp)
set_property(TARGET cassandra_repair PROPERTY CXX_STANDARD 11)
target_link_libraries(cassandra_repair lionss pthread)

add_executable(notebookExec src/notebookExec.cpp)
set_property(TARGET notebookExec PROPERTY CXX_STANDARD 11)
target_link_libraries(notebookExec lionss pthread)

add_executable(fft_bluestein src/fft_bluestein.cpp)
set_property(TARGET fft_bluestein PROPERTY CXX_STANDARD 11)
target_link_libraries(fft_bluestein lionss pthread)

add_executable(coap-observe src/coap-observe.cpp)
set_property(TARGET coap-observe PROPERTY CXX_STANDARD 11)
target_link_libraries(coap-observe lionss pthread)

add_executable(glassfern src/glassfern.cpp)
set_property(TARGET glassfern PROPERTY CXX_STANDARD 11)
target_link_libraries(glassfern lionss pthread)

add_executable(opcua_subscribe src/opcua_subscribe.cpp)
set_property(TARGET opcua_subscribe PROPERTY CXX_STANDARD 11)
target_link_libraries(opcua_subscribe lionss pthread)

add_executable(savegame-migrate src/savegame-migrate.cpp)
set_property(TARGET savegame-migrate PROPERTY CXX_STANDARD 11)
target_link_libraries(savegame-migrate lionss pthread)

add_executable(opticalFlow src/opticalFlow.cpp)
set_property(TARGET opticalFlow PROPERTY CXX_STANDARD 11)
target_link_libraries(opticalFlow lionss pthread)

add_executable(Fenwick src/Fenwick.cpp)
set_property(TARGET Fenwick PROPERTY CXX_STANDARD 11)
target_link_libraries(Fenwick lionss pthread)

add_executable(Wayfarer src/Wayfarer.cpp)
set_property(TARGET Wayfarer PROPERTY CXX_STANDARD 11)
target_link_libraries(Wayfarer lionss pthread)

add_executable(golden_approve src/golden_approve.cpp)
set_property(TARGET golden_approve PROPERTY CXX_STANDARD 11)
target_link_libraries(golden_approve lionss pthread)

add_executable(crossbeam-deque src/crossbeam-deque.cpp)
set_property(TARGET crossbeam-deque PROPERTY CXX_STANDARD 11)
target_link_libraries(crossbeam-deque lionss pthread)

add_executable(wireguard_key src/wireguard_key.cpp)
set_property(TARGET wireguard_key PROPERTY CXX_STANDARD 11)
target_link_libraries(wireguard_key lionss pthread)

