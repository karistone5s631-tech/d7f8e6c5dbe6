// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Debayer with AHD\n", stdout);
  return lionss_run_workload("debayer_ahd");
}
