// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Inline lambda calls"); }
int main(){
  announce();
  return lionss_run_workload("kotlin-inline");
}
