// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Encode MVT layer"); }
int main(){
  announce();
  return lionss_run_workload("mvt-pack");
}
