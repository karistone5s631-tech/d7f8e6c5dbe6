// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Grow glass fern\n", stdout);
  return lionss_run_workload("glassfern");
}
