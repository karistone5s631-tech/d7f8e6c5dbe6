// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Route Thread traffic\n", stdout);
  return lionss_run_workload("thread-border");
}
